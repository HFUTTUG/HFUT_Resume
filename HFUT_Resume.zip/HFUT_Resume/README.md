## 合肥工业大学个人简历 LaTeX 模板

[![Homepage Deploy](https://github.com/HFUTTUG/HFUT_Resume/actions/workflows/page_deploy.yml/badge.svg)](https://github.com/HFUTTUG/HFUT_Resume/actions/workflows/page_deploy.yml)
[![Tex Build Test](https://github.com/HFUTTUG/HFUT_Resume/actions/workflows/tex_build_test.yml/badge.svg)](https://github.com/HFUTTUG/HFUT_Resume/actions/workflows/tex_build_test.yml)
![visitors](https://visitor-badge.glitch.me/badge?page_id=HFUTTUG.HFUT_Resume)

项目主页：[HFUT_Resume Github Page](https://HFUTTUG.github.io/HFUT_Resume)

项目详细信息可通过 [**项目主页**](https://HFUTTUG.github.io/HFUT_Resume) 查看。
